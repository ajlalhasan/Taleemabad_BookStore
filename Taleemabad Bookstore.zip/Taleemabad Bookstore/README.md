# Installation 


```
    pip install django-cors-headers
    pip install django-crispy-forms
    pip install xhtml2pdf
```

</br>

![screenshot_2019-02-18 online book store 2](https://user-images.githubusercontent.com/28836413/52928808-cddf6e00-336b-11e9-9db9-58cb0fc0f0e5.png)


![Screenshot_2019-09-07 Online Book Store](https://user-images.githubusercontent.com/16104417/64470406-7a483c80-d164-11e9-93b1-cbca68a966cb.png)
